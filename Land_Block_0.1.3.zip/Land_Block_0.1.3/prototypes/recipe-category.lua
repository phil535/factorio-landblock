data:extend(
{
  {
    type = "recipe-category",
    name = "crafting-handonly"
  },
  {
    type = "recipe-category",
    name = "thermal-extractor",
  }
})
