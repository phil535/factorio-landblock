# LandBlock for Factorio 0.17.79
Just like SeaBlock, except on land. Adjustable settings.
